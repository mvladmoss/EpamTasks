package com.epam.geometry.validator;

public interface Validator{
    boolean validate(String toValidate);
}
