package com.epam.geometry.registar;

public interface Observer<T>{
    void update(T t);
}
